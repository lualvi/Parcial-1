/**
 * CLASE PrintManager: es la clase principal que simula el servicio de impresion.
 * Se encarga de crear el servicio de impresion, enviar trabajos de usuarios y procesarlos.
 */
public class PrintManager {
    public static void main(String[] args) {
        // crear una instancia para el servicio de impresion
        PrintService printService = new PrintService();

        // simulamos la entrada de trabajos de impresion
        printService.sendJob("user1", PrintJob.Priority.H); // alta prioridad
        printService.sendJob("user2", PrintJob.Priority.L); // baja prioridad
        printService.sendJob("user3");                      // media prioridad (por defecto)
        printService.sendJob("user4", PrintJob.Priority.M); // media prioridad
        printService.sendJob("user5", PrintJob.Priority.H); // alta prioridad

        // procesamos los trabajos en la cola
        System.out.println("\nProcessing print jobs:");
        printService.processJobs();
    }
}
