import java.time.LocalDateTime;

/**
 * CLASE PrintJob: representa un trabajo de impresion
 * Implementa la interfaz Comparable para poder ordenar los trabajos
 * por prioridad y, en caso de igual prioridad, por hora de envio.
 */
public class PrintJob implements Comparable<PrintJob> {
    private String username; // Nombre del usuario que envia el trabajo
    private LocalDateTime submissionTime; // Hora en que se envia el trabajo
    private Priority priority; // Prioridad del trabajo (L, M, H)

    /**
     * Enumeraci�n que define los niveles de prioridad de un trabajo de impresion.
     */
    public enum Priority {
        L, M, H
    }

    /**
     * Constructor que permite especificar todos los atributos del trabajo de impresion
     * @param username El nombre del usuario que envia el trabajo.
     * @param submissionTime La hora de envio del trabajo.
     * @param priority La prioridad del trabajo (L, M, H).
     */
    public PrintJob(String username, LocalDateTime submissionTime, Priority priority) {
        this.username = username;
        this.submissionTime = submissionTime;
        this.priority = priority;
    }

    /**
     * Constructor que asigna una prioridad por defecto de 'M' (Media).
     * @param username El nombre del usuario que envia el trabajo.
     * @param submissionTime La hora de envio del trabajo.
     */
    public PrintJob(String username, LocalDateTime submissionTime) {
        this(username, submissionTime, Priority.M); // Prioridad por defecto M
    }

    /**
     * obtiene el nombre del usuario.
     * @return El nombre del usuario.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Obtiene la hora de envio del trabajo.
     * @return La hora de envio.
     */
    public LocalDateTime getSubmissionTime() {
        return submissionTime;
    }

    /**
     * obtiene la prioridad del trabajo.
     * @return La prioridad del trabajo.
     */
    public Priority getPriority() {
        return priority;
    }

    /**
     * Metodo que compara dos trabajos de impresion. Primero, compara las prioridades;
     * si las prioridades son iguales, compara las horas de envio.
     * @param other El otro trabajo de impresion a comparar.
     * @return Un valor negativo si este trabajo tiene mayor prioridad o fue enviado antes.
     */
    @Override
    public int compareTo(PrintJob other) {
        // Primero comparamos por prioridad (H > M > L)
        int priorityComparison = this.priority.compareTo(other.priority);
        if (priorityComparison != 0) {
            return -priorityComparison; // Para que H sea primero y L �ltimo
        }
        // Si tienen la misma prioridad, comparamos por tiempo de envio
        return this.submissionTime.compareTo(other.submissionTime);
    }

    /**
     * Metodo que genera una representacion en cadena de un trabajo de impresion.
     * @return Una cadena con los detalles del trabajo de impresion.
     */
    @Override
    public String toString() {
        return "User: " + username + ", Submission Time: " + submissionTime + ", Priority: " + priority;
    }
}
