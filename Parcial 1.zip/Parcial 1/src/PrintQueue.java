import java.util.PriorityQueue;

/**
 * CLASE PrintQueue: maneja una cola de trabajos de impresion, garantizando
 * que se procesen en orden de prioridad y tiempo de envio
 */
public class PrintQueue {
    private PriorityQueue<PrintJob> queue; // cola de trabajos de impresion

    /**
     * Constructor que inicializa la cola de trabajos de impresion utilizando una PriorityQueue
     */
    public PrintQueue() {
        this.queue = new PriorityQueue<>();
    }

    /**
     * Agrega un trabajo de impresion a la cola.
     * @param job El trabajo de impresion a agregar.
     */
    public void addJob(PrintJob job) {
        queue.offer(job);
        System.out.println("Job added: " + job);
    }

    /**
     * Procesa el siguiente trabajo en la cola. Si la cola esta vacia, muestra un mensaje.
     * @return El trabajo de impresion procesado, o null si la cola esta vacia.
     */
    public PrintJob processNextJob() {
        if (!queue.isEmpty()) {
            PrintJob nextJob = queue.poll();
            System.out.println("Processing job: " + nextJob);
            return nextJob;
        } else {
            System.out.println("No jobs to process.");
            return null;
        }
    }

    /**
     * Muestra el siguiente trabajo en la cola sin eliminarlo.
     * @return El siguiente trabajo en la cola.
     */
    public PrintJob peekNextJob() {
        return queue.peek();
    }

    /**
     * Verifica si la cola esta vacia.
     * @return true si la cola esta vacia, false en caso contrario.
     */
    public boolean isEmpty() {
        return queue.isEmpty();
    }
}
