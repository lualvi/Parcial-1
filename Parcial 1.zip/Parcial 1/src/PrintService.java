import java.time.LocalDateTime;

/**
 * CLASE PrintService: simula el servicio de impresion, permitiendo
 * a los usuarios enviar trabajos de impresion y procesarlos en orden de prioridad.
 */
public class PrintService {
    private PrintQueue printQueue; // cola de trabajos de impresion

    /**
     * Constructor que inicializa el servicio de impresion con una nueva PrintQueue
     */
    public PrintService() {
        this.printQueue = new PrintQueue();
    }

    /**
     * este envia un trabajo de impresion con una prioridad especificada
     * @param username El nombre del usuario que envia el trabajo.
     * @param priority La prioridad del trabajo.
     */
    public void sendJob(String username, PrintJob.Priority priority) {
        PrintJob job = new PrintJob(username, LocalDateTime.now(), priority);
        printQueue.addJob(job);
    }

    /**
     * Envia un trabajo de impresion con prioridad por defecto (Media).
     * @param username El nombre del usuario que env�a el trabajo.
     */
    public void sendJob(String username) {
        PrintJob job = new PrintJob(username, LocalDateTime.now());
        printQueue.addJob(job);
    }

    /**
     * procesa todos los trabajos de impresion en la cola en orden de prioridad.
     */
    public void processJobs() {
        while (!printQueue.isEmpty()) {
            printQueue.processNextJob();
        }
    }
}
